./scripts/run_depparse.sh Chinese gold --batch_size 1000
./scripts/run_depparse.sh Chinese gold --batch_size 1000 --tag_emb_dim 150 --word_emb_dim 150 --hidden_dim 600
./scripts/run_depparse.sh Chinese gold --batch_size 1000 --tag_emb_dim 200 --word_emb_dim 150 --no_char --lr 0.001
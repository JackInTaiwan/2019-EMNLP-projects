""" Single source of truth for version number """

__version__ = "0.1.3"

x = '我是'
print(x.lower())